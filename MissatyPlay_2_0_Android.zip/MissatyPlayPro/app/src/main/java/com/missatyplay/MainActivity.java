package com.missatyplay;

import android.app.*;import android.os.*;import android.content.*;import android.database.Cursor;import android.net.Uri;import android.provider.OpenableColumns;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 static final int PICK=10; ArrayList<Uri> songs=new ArrayList<>(); ArrayList<String> names=new ArrayList<>(); int current=-1; boolean favorite=false; SharedPreferences prefs; MediaPlayer player;
 ListView list; ArrayAdapter<String> adapter; TextView title,artist; ImageButton play,fav;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); prefs=getSharedPreferences("mp",0); list=findViewById(R.id.list); title=findViewById(R.id.title);artist=findViewById(R.id.artist);play=findViewById(R.id.playButton);fav=findViewById(R.id.favButton);
  adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names){public View getView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getView(p,v,g);t.setTextColor(0xffffffff);t.setTextSize(16);t.setPadding(16,20,16,20);return t;}};list.setAdapter(adapter);
  findViewById(R.id.addButton).setOnClickListener(v->pick()); list.setOnItemClickListener((a,v,p,id)->playIndex(p)); play.setOnClickListener(v->toggle()); fav.setOnClickListener(v->{favorite=!favorite;fav.setImageResource(favorite?android.R.drawable.btn_star_big_on:android.R.drawable.btn_star_big_off);});
  findViewById(R.id.timerButton).setOnClickListener(v->timer());
 }
 void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK)return;if(d.getClipData()!=null){for(int i=0;i<d.getClipData().getItemCount();i++)add(d.getClipData().getItemAt(i).getUri());}else if(d.getData()!=null)add(d.getData());adapter.notifyDataSetChanged();}
 void add(Uri u){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception e){}songs.add(u);names.add(name(u));}
 String name(Uri u){String n="Música";Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&x>=0)n=c.getString(x);c.close();}return n;}
 void playIndex(int p){current=p; if(player!=null)player.release(); player=MediaPlayer.create(this,songs.get(p)); if(player==null)return; player.setOnCompletionListener(x->{if(p+1<songs.size())playIndex(p+1);else play.setImageResource(android.R.drawable.ic_media_play);});player.start(); title.setText(names.get(p));artist.setText("MissatyPlay • Biblioteca");play.setImageResource(android.R.drawable.ic_media_pause); startService(new Intent(this,PlayerService.class).setAction(PlayerService.ACTION_PLAY));}
 void toggle(){if(player==null){if(!songs.isEmpty())playIndex(0);return;}if(player.isPlaying()){player.pause();play.setImageResource(android.R.drawable.ic_media_play);stopService(new Intent(this,PlayerService.class));}else{player.start();play.setImageResource(android.R.drawable.ic_media_pause);startService(new Intent(this,PlayerService.class).setAction(PlayerService.ACTION_PLAY));}}
 void timer(){final String[] opts={"5 minutos","10 minutos","15 minutos","20 minutos","30 minutos","45 minutos","60 minutos","90 minutos","120 minutos"}; new AlertDialog.Builder(this).setTitle("Temporizador").setItems(opts,(d,w)->{int min=new int[]{5,10,15,20,30,45,60,90,120}[w]; new Handler().postDelayed(()->{if(player!=null&&player.isPlaying()){player.pause();play.setImageResource(android.R.drawable.ic_media_play);} stopService(new Intent(this,PlayerService.class));},min*60000L);Toast.makeText(this,"Vai parar em "+opts[w],Toast.LENGTH_SHORT).show();}).show();}
}
