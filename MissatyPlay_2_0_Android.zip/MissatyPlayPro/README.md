# MissatyPlay 2.0
Player Android com biblioteca local, favoritos, temporizador, reprodução em segundo plano e notificação.

Abra no Android Studio e use Build > Build APK(s).

Observação: o serviço mantém a notificação em primeiro plano; para controles completos de play/pausa/próxima na tela bloqueada, a próxima evolução deve usar MediaSession/Media3.
